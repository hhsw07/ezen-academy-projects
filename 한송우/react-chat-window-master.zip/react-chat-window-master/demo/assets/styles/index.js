import "./base.css";
import "./header.css";
import "./test-area.css";
import "./footer.css";