package com.cookandroid.funfun.vo;

public class store {
    private int sto_code;
    private int pro_code;
    private String reg_date;
    private String sub_date;
    private String sto_title;
    private String sto_detail;
    private int sto_image;
    private String sto_curr;
    private String cate_title;
    private int sto_price;
    private String maker_name;

    public store(int sto_code, String sto_title, String cate_title, int sto_price, int sto_image){
        this.sto_title = sto_title;
        this.cate_title = cate_title;
        this.sto_price = sto_price;
        this.sto_image = sto_image;
    }
    public int getSto_code() {
        return sto_code;
    }
    public void setSto_code(int sto_code) {
        this.sto_code = sto_code;
    }
    public int getPro_code() {
        return pro_code;
    }
    public void setPro_code(int pro_code) {
        this.pro_code = pro_code;
    }
    public String getReg_date() {
        return reg_date;
    }
    public void setReg_date(String reg_date) {
        this.reg_date = reg_date;
    }
    public String getSub_date() {
        return sub_date;
    }
    public void setSub_date(String sub_date) {
        this.sub_date = sub_date;
    }
    public String getSto_title() {
        return sto_title;
    }
    public void setSto_title(String sto_title) {
        this.sto_title = sto_title;
    }
    public String getSto_detail() {
        return sto_detail;
    }
    public void setSto_detail(String sto_detail) {
        this.sto_detail = sto_detail;
    }
    public int getSto_image() {
        return sto_image;
    }
    public void setSto_image(int sto_image) {
        this.sto_image = sto_image;
    }
    public String getSto_curr() {
        return sto_curr;
    }
    public void setSto_curr(String sto_curr) {
        this.sto_curr = sto_curr;
    }
    public String getCate_title() {
        return cate_title;
    }
    public void setCate_title(String cate_title) {
        this.cate_title = cate_title;
    }
    public int getSto_price() {
        return sto_price;
    }
    public void setSto_price(int sto_price) {
        this.sto_price = sto_price;
    }
    public String getMaker_name() {
        return maker_name;
    }
    public void setMaker_name(String maker_name) {
        this.maker_name = maker_name;
    }
}
