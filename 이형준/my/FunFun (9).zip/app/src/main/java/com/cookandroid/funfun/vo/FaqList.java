package com.cookandroid.funfun.vo;

import java.util.ArrayList;

public class FaqList {
    private ArrayList<Faq> list;

    public ArrayList<Faq> getList() {
        return list;
    }

    public void setList(ArrayList<Faq> list) {
        this.list = list;
    }
}
