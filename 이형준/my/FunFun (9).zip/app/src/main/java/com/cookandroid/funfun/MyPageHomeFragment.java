package com.cookandroid.funfun;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.cookandroid.funfun.vo.Project;
import com.cookandroid.funfun.vo.ProjectList;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;


public class MyPageHomeFragment extends Fragment {


    String user;
    AlertDialog.Builder builder;
    static RequestQueue requestQueue;
    TextView mName;
    TextView logoutBtn;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v=inflater.inflate(R.layout.fragment_my_page_home, container, false);
        user = getArguments().getString("user");
        if (requestQueue == null) {
            requestQueue = Volley.newRequestQueue(getActivity());
        }
        mName = v.findViewById(R.id.name1);
        if(user!=null){
            makeRequest(user);
        }

        logoutBtn=v.findViewById(R.id.logoutBtn);
        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutAlert();
            }
        });
        return v;
    }


    public void makeRequest(String user){
        String url = "http://192.168.4.116:5080/funfun/getName.do?email="+user;
        StringRequest request = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                         processResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<String,String>();

                return params;
            }
        };
        request.setShouldCache(false);
        requestQueue.add(request);
    }

    public void processResponse(String response){
        Gson gson = new Gson();
        Log.d("MyPageHomeFragment", response);
        NameVo _name_ = gson.fromJson(response, NameVo.class);
        mName.setText(_name_.getName());

    }

    private void logoutAlert() {
        builder = new AlertDialog.Builder(getActivity());

        builder.setTitle("로그아웃하시겠습니까?").setMessage("로그아웃 하시면 메인페이지로 이동합니다.");

        builder.setPositiveButton("로그아웃", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                Intent intent = new Intent(getActivity(), MainActivity.class);
                intent.putExtra("user", "");
                startActivity(intent);
                getActivity().finish();
            }
        });

        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {

            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }


}

class NameVo{
    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}