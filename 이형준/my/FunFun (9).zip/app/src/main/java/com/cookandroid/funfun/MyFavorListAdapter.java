package com.cookandroid.funfun;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cookandroid.funfun.vo.MyFavor;
import com.cookandroid.funfun.vo.Project;

import java.util.ArrayList;

public class MyFavorListAdapter extends RecyclerView.Adapter<MyFavorListAdapter.ViewHolder> {
    ArrayList<MyFavor> items = new ArrayList<MyFavor>();

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View itemView = inflater.inflate(R.layout.favor_project_item, viewGroup, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
        MyFavor item = items.get(position);
        viewHolder.setItem(item);

    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public void addItem(MyFavor item){
        items.add(item);
    }
    public void setItems(ArrayList<MyFavor> items){
        this.items = items;
    }
    public MyFavor getItem(int position){
        return items.get(position);
    }
    static class ViewHolder extends RecyclerView.ViewHolder{
        TextView title;
        TextView cate;
        TextView dDay;
        ImageView imgView;
        public ViewHolder(View itemView){
            super(itemView);
            title = itemView.findViewById(R.id.project_title);
            cate = itemView.findViewById(R.id.cate_txt);
            dDay = itemView.findViewById(R.id.dDay1);
            imgView=itemView.findViewById(R.id.imgView);
        }
        public void setItem(MyFavor item){
            title.setText(item.getProTitle());
            cate.setText(item.getCateTitle());
            dDay.setText(item.getdDay());
            imgView.setImageURI(item.getImgSrc());
        }
    }
}
