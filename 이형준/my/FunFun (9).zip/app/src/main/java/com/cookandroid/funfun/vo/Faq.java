package com.cookandroid.funfun.vo;

public class Faq {
    private String faq_code;
    private int cnt;
    private String faq_upt_date;
    private int admin_code;
    private String faq_detail;
    private String admin_name;
    private String faq_title;
    private String faq_category;
    private String faq_reg_date;

    public String getFaq_code() {
        return faq_code;
    }

    public void setFaq_code(String faq_code) {
        this.faq_code = faq_code;
    }

    public int getCnt() {
        return cnt;
    }

    public void setCnt(int cnt) {
        this.cnt = cnt;
    }

    public String getFaq_upt_date() {
        return faq_upt_date;
    }

    public void setFaq_upt_date(String faq_upt_date) {
        this.faq_upt_date = faq_upt_date;
    }

    public int getAdmin_code() {
        return admin_code;
    }

    public void setAdmin_code(int admin_code) {
        this.admin_code = admin_code;
    }

    public String getFaq_detail() {
        return faq_detail;
    }

    public void setFaq_detail(String faq_detail) {
        this.faq_detail = faq_detail;
    }

    public String getAdmin_name() {
        return admin_name;
    }

    public void setAdmin_name(String admin_name) {
        this.admin_name = admin_name;
    }

    public String getFaq_title() {
        return faq_title;
    }

    public void setFaq_title(String faq_title) {
        this.faq_title = faq_title;
    }

    public String getFaq_category() {
        return faq_category;
    }

    public void setFaq_category(String faq_category) {
        this.faq_category = faq_category;
    }

    public String getFaq_reg_date() {
        return faq_reg_date;
    }

    public void setFaq_reg_date(String faq_reg_date) {
        this.faq_reg_date = faq_reg_date;
    }
}
