package com.cookandroid.funfun;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.cookandroid.funfun.vo.LoginResult;
import com.google.gson.Gson;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.cookandroid.funfun.FundingFragment.requestQueue;

public class LoginActivity extends AppCompatActivity {

    EditText editEmail;
    EditText editPass;
    TextView signupBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        signupBtn = findViewById(R.id.signupBtn);
        editEmail = findViewById(R.id.editEmail);
        editPass = findViewById(R.id.editPass);

        TextView header = findViewById(R.id.appbar_header);
        header.setText("로그인");
        ImageButton backBtn = findViewById(R.id.back_button);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        // 회원가입 페이지로 이동
        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), SignupActivity.class));
            }
        });

        // 아이디/비밀번호 찾기 페이지로 이동
        TextView findIdBtn = findViewById(R.id.findBtn);
        findIdBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), FindActivity.class));
            }
        });

        //로그인
        Button loginBtn = findViewById(R.id.loginBtn);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //백그라운드 스레드 생성
                Toast.makeText(getApplicationContext(), "로그인 중..", Toast.LENGTH_SHORT).show();
                new Thread(new Runnable(){
                    public void run(){
                        makeRequest();
                    }
                }).start();
            }
        });

        if (requestQueue == null) {
            requestQueue = Volley.newRequestQueue(getApplicationContext());
        }



    }

    public void makeRequest(){
        String url = "http://192.168.4.116:5080/funfun/androidlogin.do?mem_email="+editEmail.getText().toString()+"&mem_pw="+editPass.getText().toString();
        StringRequest request = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getApplicationContext(), "응답", Toast.LENGTH_SHORT);
                        Log.d("응답 -> " , response);
                        handleResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("에러 -> " , error.getMessage());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<String,String>();

                return params;
            }


        };
        request.setShouldCache(false);
        requestQueue.add(request);
    }

    private void handleResponse(String response){
        Log.d("LoginActivity", response);
        Gson gson = new Gson();
        LoginResult loginResult=gson.fromJson(response, LoginResult.class);
        if(loginResult.isResult()){
            Log.d("LoginActivity", "로그인 성공");
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("로그인성공").setMessage("메인페이지로 이동합니다.");
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.putExtra("user", loginResult.getMem_email());
            startActivity(intent);
            finish();
        } else {
            Log.d("LoginActivity", "로그인 실패");
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("로그인 실패").setMessage("이메일/비밀번호를 다시 확인해주세요.");
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
    }
}
