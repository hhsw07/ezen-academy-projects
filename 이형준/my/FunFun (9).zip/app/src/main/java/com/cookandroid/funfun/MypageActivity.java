package com.cookandroid.funfun;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.cookandroid.funfun.vo.FavorList;
import com.cookandroid.funfun.vo.mypageVo;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;

public class MypageActivity extends AppCompatActivity {
    private BottomNavigationView bottomNavigationView; // 바텀 네비게이션 뷰
    AlertDialog.Builder builder;
    String user;
    TextView headerTitle;
    MyPageHomeFragment myPageHomeFragment;
    MyPageInterestFragment myPageInterestFragment;
    MyPageFundingFragment myPageFundingFragment;
    MyPageOrderFragment myPageOrderFragment;

    FragmentManager fragmentManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_mypage);
        headerTitle=findViewById(R.id.appbar_header);
        headerTitle.setText("마이페이지");
        //뒤로가기 버튼 누르는 경우
        ImageButton backBtn = findViewById(R.id.back_button);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        fragmentManager=getSupportFragmentManager();
        Intent intent=getIntent();
        user=intent.getStringExtra("user");


        Bundle bundle = new Bundle();
        bundle.putString("user", user);
        myPageHomeFragment=new MyPageHomeFragment();
        myPageHomeFragment.setArguments(bundle);
        myPageInterestFragment=new MyPageInterestFragment();
        myPageInterestFragment.setArguments(bundle);
        myPageFundingFragment=new MyPageFundingFragment();
        myPageFundingFragment.setArguments(bundle);
        myPageOrderFragment= new MyPageOrderFragment();
        myPageOrderFragment.setArguments(bundle);
        //비로그인의 경우
        if(user==null||"".equals(user)){
            loginAlert();
        }

        fragmentManager.beginTransaction().replace(R.id.frameLayout, myPageHomeFragment).commit();
        //하단 메뉴 버튼마다 이동 이벤트 세팅
        bottomNavigationView = findViewById(R.id.navigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch(menuItem.getItemId()){
                    case R.id.home1:
                        fragmentManager.beginTransaction().replace(R.id.frameLayout, myPageHomeFragment).commit();
                        break;
                    case R.id.interest1:
                        fragmentManager.beginTransaction().replace(R.id.frameLayout, myPageInterestFragment).commit();
                        break;
                    case R.id.funding1:
                        fragmentManager.beginTransaction().replace(R.id.frameLayout, myPageFundingFragment).commit();
                        break;
                    case R.id.store1:
                        fragmentManager.beginTransaction().replace(R.id.frameLayout, myPageOrderFragment).commit();
                        break;
                }

                return true;
            }
        });



    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Toast.makeText(getApplicationContext(), "onNewIntent실행", Toast.LENGTH_SHORT).show();
    }

    private void loginAlert() {
        builder = new AlertDialog.Builder(this);

        builder.setTitle("해당 서비스 이용을 위해서는 로그인이 필요합니다.").setMessage("로그인 하시겠습니까?");

        builder.setPositiveButton("로그인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                finish();
            }
        });

        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                finish();
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}
