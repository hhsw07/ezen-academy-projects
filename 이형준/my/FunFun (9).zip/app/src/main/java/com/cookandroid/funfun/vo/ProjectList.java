package com.cookandroid.funfun.vo;

import java.util.ArrayList;

public class ProjectList {
    private ArrayList<Project> plist;

    public ArrayList<Project> getPlist() {
        return plist;
    }
    public void setPlist(ArrayList<Project> plist) {
        this.plist = plist;
    }
}
