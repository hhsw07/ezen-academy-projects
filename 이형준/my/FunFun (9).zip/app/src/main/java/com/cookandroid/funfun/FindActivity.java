package com.cookandroid.funfun;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class FindActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView; // 바텀 네비게이션 뷰
    FindIdFragment findIdFragment;
    FindPassFragment findPassFragment;
    FragmentManager fragmentManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find);
        ImageButton backBtn = findViewById(R.id.back_button);
        findIdFragment=new FindIdFragment();
        findPassFragment=new FindPassFragment();
        fragmentManager = getSupportFragmentManager();
        TextView header = findViewById(R.id.appbar_header);
        header.setText("아이디/비밀번호 찾기");
        fragmentManager.beginTransaction().replace(R.id.frameLayout, findIdFragment).commit();


        //뒤로가기 버튼
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //하단 메뉴 버튼마다 이동 이벤트 세팅
        bottomNavigationView = findViewById(R.id.navigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch(menuItem.getItemId()){
                    case R.id.emailicon:
                        fragmentManager.beginTransaction().replace(R.id.frameLayout, findIdFragment).commit();
                        break;
                    case R.id.passwordicon:
                        fragmentManager.beginTransaction().replace(R.id.frameLayout, findPassFragment).commit();
                        break;
                }

                return true;
            }
        });
    }
}
