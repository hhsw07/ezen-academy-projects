package com.cookandroid.funfun;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.cookandroid.funfun.vo.MyFavor;
import com.cookandroid.funfun.vo.MyFavorList;
import com.cookandroid.funfun.vo.Project;
import com.cookandroid.funfun.vo.ProjectList;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;


public class MyPageInterestFragment extends Fragment {

    static RequestQueue requestQueue;
    RecyclerView recyclerView;
    MyFavorListAdapter adapter;
    LinearLayoutManager layoutManager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v =inflater.inflate(R.layout.fragment_my_page_interest, container, false);
        // Inflate the layout for this fragment
        if (requestQueue == null) {
            requestQueue = Volley.newRequestQueue(getActivity());
        }

        makeRequest();

        recyclerView = v.findViewById(R.id.recyclerview1);
        System.out.println(recyclerView);
        layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        println(recyclerView.toString());
        recyclerView.setLayoutManager(layoutManager);

        adapter = new MyFavorListAdapter();

        recyclerView.setAdapter(adapter);

        return v;
    }

    public void makeRequest(){
        String url = "http://192.168.4.116:5080/funfun/getFavorList.do?email=himan1234@gmail.com";
        StringRequest request = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        println("응답 -> " + response);

                        processResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        println("에러 -> " + error.getMessage());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<String,String>();

                return params;
            }
        };
        request.setShouldCache(false);
        requestQueue.add(request);
        println("요청 보냄.");
    }

    public void println(String data) {
        Log.d("MyPageInterestFragment", data);
    }
    public void processResponse(String response){
        Gson gson = new Gson();
        MyFavorList myFavorList = gson.fromJson(response, MyFavorList.class);
        for(int i = 0 ; i < myFavorList.getFavorList().size() ; i++){
            MyFavor myFavor = myFavorList.getFavorList().get(i);
            int ranNumber=(int)Math.random()*100;
            myFavor.setImgSrc("https://picsum.photos/300/200/?random?"+ranNumber);
            adapter.addItem(myFavor);
        }
        Log.d("FundingFragment", "로딩");
        adapter.notifyDataSetChanged();
    }

    
}
