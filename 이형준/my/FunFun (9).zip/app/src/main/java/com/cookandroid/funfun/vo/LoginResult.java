package com.cookandroid.funfun.vo;

public class LoginResult {
    private boolean result;
    private String mem_email;

    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    public String getMem_email() {
        return mem_email;
    }

    public void setMem_email(String mem_email) {
        this.mem_email = mem_email;
    }
}
