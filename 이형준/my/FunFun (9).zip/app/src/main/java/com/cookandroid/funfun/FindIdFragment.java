package com.cookandroid.funfun;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.cookandroid.funfun.vo.LoginResult;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;

import static com.cookandroid.funfun.FundingFragment.requestQueue;


public class FindIdFragment extends Fragment {

    EditText editEmail;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
//        Toast.makeText(getActivity(), "onCreateView 호출", Toast.LENGTH_SHORT).show();
        View v = inflater.inflate(R.layout.fragment_find_id, container, false);
        Button findIdBtn = v.findViewById(R.id.findIdBtn);
        editEmail = v.findViewById(R.id.editEmail);
        findIdBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailStr=editEmail.getText().toString();
                Log.d("FindIdFragment", "클릭");
                Log.d("FindIdFragment", "확인하려는 아이디:"+emailStr);
                if(emailStr!=null&&emailStr.equals("")){
                    alertBox("이메일을 입력해주세요", "입력이 비어있습니다.");
                    Log.d("FindIdFragment", "이메일이 빈 경우");

                } else if(emailStr!=null&&!emailStr.equals("")){
                    Log.d("FindIdFragment", "컨펌실행");
                    confirmId(emailStr);
                } else{
                    alertBox("이메일을 입력해주세요", "입력이 비어있습니다.");
                }
            }
        });

        return v;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {

//        Toast.makeText(getActivity(), "onCreate 호출", Toast.LENGTH_SHORT).show();
        super.onCreate(savedInstanceState);
    }

    private void alertBox(String str1, String str2){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(str1).setMessage(str2);
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    public void confirmId(String email){
        String url = "http://192.168.4.116:5080/funfun/signupIdCheck.do?mem_email="+email;
        StringRequest request = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.d("FindIdFragment" , "응답:"+response);

                        handleconfirm(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("FindIdFragment" , "에러:"+error.getMessage());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<String,String>();

                return params;
            }


        };
        request.setShouldCache(false);
        requestQueue.add(request);
    }

    private void handleconfirm(String response){
        Gson gson = new Gson();
        ConfirmVo confirm=gson.fromJson(response, ConfirmVo.class);
        Log.d("FindIdFragment" , "confirm.isVerification():"+confirm.isVerification());
        if(!confirm.isVerification()){
            alertBox("이미 가입된 이메일입니다.", "");
        } else{
            alertBox("가입되지 않은 이메일입니다.", "해당 이메일로 회원가입을 하실 수 있습니다.");
        }
    }
}


class ConfirmVo{
    boolean verification;

    public boolean isVerification() {
        return verification;
    }

    public void setVerification(boolean verification) {
        this.verification = verification;
    }
}
