package com.cookandroid.funfun.vo;

import java.util.ArrayList;

public class FavorList {
    private ArrayList<mypageVo> list;


    public ArrayList<mypageVo> getList() {
        return list;
    }

    public void setList(ArrayList<mypageVo> list) {
        this.list = list;
    }
}
