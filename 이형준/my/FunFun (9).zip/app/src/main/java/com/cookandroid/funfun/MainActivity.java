package com.cookandroid.funfun;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView; // 바텀 네비게이션 뷰
    MainFragment mainFragment;
    FundingFragment fundingFragment;
    StoreFragment storeFragment;
    NoticeFragment0 noticeFragment0;
    String user;
    FragmentManager fragmentManager;
    @Override
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar tb = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(tb);
        Log.d("tb", tb.toString());
        mainFragment = new MainFragment();
        fundingFragment = new FundingFragment();
        storeFragment = new StoreFragment();
        noticeFragment0 = new NoticeFragment0();

        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frameLayout, mainFragment).commit();
        //하단 메뉴 버튼마다 이동 이벤트 세팅
        bottomNavigationView = findViewById(R.id.navigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch(menuItem.getItemId()){
                    case R.id.home1:
                        fragmentManager.beginTransaction().replace(R.id.frameLayout, mainFragment).commit();
                        break;
                    case R.id.funding1:
                        fragmentManager.beginTransaction().replace(R.id.frameLayout, fundingFragment).commit();
                        break;
                    case R.id.store1:
                        fragmentManager.beginTransaction().replace(R.id.frameLayout, storeFragment).commit();
                        break;
                    case R.id.notice1:
                        fragmentManager.beginTransaction().replace(R.id.frameLayout, noticeFragment0).commit();
                        break;
                }

                return true;
            }
        });


        //마이페이지로 이동
        ImageButton mMypage = (ImageButton)findViewById(R.id.mypage1);
        mMypage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(getApplicationContext(), MypageActivity.class);
                intent1.putExtra("user", user);
                startActivity(intent1);
            }
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        //Toast.makeText(getApplicationContext(), "onNewIntent호출", Toast.LENGTH_SHORT).show();
        user=intent.getStringExtra("user");
        Toast.makeText(getApplicationContext(), "접속 유저 : "+user, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();

    }
}
