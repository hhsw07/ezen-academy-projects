package com.cookandroid.funfun;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.cookandroid.funfun.vo.Project;
import com.cookandroid.funfun.vo.ProjectList;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;


public class FundingFragment extends Fragment {

    static RequestQueue requestQueue;
    RecyclerView recyclerView;
    ProjectAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v=inflater.inflate(R.layout.fragment_funding, container, false);

        if (requestQueue == null) {
            requestQueue = Volley.newRequestQueue(getActivity());
        }

        makeRequest();

        recyclerView = v.findViewById(R.id.project_list);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new ProjectAdapter();
        recyclerView.setAdapter(adapter);

        return v;
    }


    public void makeRequest(){
        String url = "http://192.168.4.116:5080/funfun/funding.do?method=ajaxList";
        StringRequest request = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        println("응답 -> " + response);

                        processResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        println("에러 -> " + error.getMessage());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<String,String>();

                return params;
            }
        };
        request.setShouldCache(false);
        requestQueue.add(request);
        println("요청 보냄.");
    }
    public void println(String data) {
        Log.d("MainActivity", data);
    }
    public void processResponse(String response){
        Gson gson = new Gson();
        ProjectList projectList = gson.fromJson(response, ProjectList.class);
        for(int i = 0 ; i < projectList.getPlist().size() ; i++){
            Project project = projectList.getPlist().get(i);
            adapter.addItem(project);
        }
        Log.d("FundingFragment", "로딩");
        adapter.notifyDataSetChanged();
    }


}
