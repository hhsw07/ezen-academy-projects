package com.cookandroid.funfun;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;


public class NoticeFragment0 extends Fragment {
    String sc_color1 = "#FF9E00";
    String sc_color2 = "#FFFFFF";
    FaqFragment faqFragment;
    RtqnaFragment rtqnaFragment;
    NoticeFragment noticeFragment;
    FragmentManager fm;
    TextView faqBtn;
    TextView noticeBtn;
    TextView rtQnaBtn;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        faqFragment=new FaqFragment();
        rtqnaFragment= new RtqnaFragment();
        noticeFragment=new NoticeFragment();


        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_notice0, container, false);

        fm=getFragmentManager();

        fm.beginTransaction().replace(R.id.sc_frame, faqFragment).commit();


        noticeBtn= v.findViewById(R.id.nav_notice);
        faqBtn=v.findViewById(R.id.nav_faq);
        rtQnaBtn=v.findViewById(R.id.nav_rtqna);

        faqBtn.setBackgroundColor(Color.parseColor(sc_color2));
        faqBtn.setTextColor(Color.parseColor(sc_color1));

        noticeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fm.beginTransaction().replace(R.id.sc_frame, noticeFragment).commit();
                initialize();
                noticeBtn.setBackgroundColor(Color.parseColor(sc_color1));
                noticeBtn.setTextColor(Color.parseColor(sc_color2));
            }
        });

        faqBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fm.beginTransaction().replace(R.id.sc_frame, faqFragment).commit();
                initialize();
                faqBtn.setBackgroundColor(Color.parseColor(sc_color1));
                faqBtn.setTextColor(Color.parseColor(sc_color2));
            }
        });

        rtQnaBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fm.beginTransaction().replace(R.id.sc_frame, rtqnaFragment).commit();
                initialize();
                rtQnaBtn.setBackgroundColor(Color.parseColor(sc_color1));
                rtQnaBtn.setTextColor(Color.parseColor(sc_color2));
            }
        });



        return v;
    }

    void initialize(){
        noticeBtn.setBackgroundColor(Color.parseColor(sc_color2));
        noticeBtn.setTextColor(Color.parseColor(sc_color1));
        faqBtn.setBackgroundColor(Color.parseColor(sc_color2));
        faqBtn.setTextColor(Color.parseColor(sc_color1));
        rtQnaBtn.setBackgroundColor(Color.parseColor(sc_color2));
        rtQnaBtn.setTextColor(Color.parseColor(sc_color1));
    }


}
