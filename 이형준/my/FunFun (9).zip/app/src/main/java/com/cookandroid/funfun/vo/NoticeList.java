package com.cookandroid.funfun.vo;

import java.util.ArrayList;

public class NoticeList {
    private ArrayList<Notice> list;
    private ArrayList<Notice> toplist;

    public ArrayList<Notice> getList() {
        return list;
    }

    public void setList(ArrayList<Notice> list) {
        list = list;
    }

    public ArrayList<Notice> getToplist() {
        return toplist;
    }

    public void setToplist(ArrayList<Notice> toplist) {
        this.toplist = toplist;
    }
}
