package com.cookandroid.funfun;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

import static com.cookandroid.funfun.FundingFragment.requestQueue;

public class SignupActivity extends AppCompatActivity {


    EditText editEmail;
    EditText editName;
    EditText editPass;
    Spinner category;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        TextView header=findViewById(R.id.appbar_header);
        header.setText("회원가입");

        ImageButton backBtn = findViewById(R.id.back_button);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Button loginBtn = findViewById(R.id.loginBtn);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editEmail=findViewById(R.id.editEmail);
                editName=findViewById(R.id.editName);
                editPass=findViewById(R.id.editPass);
                category=findViewById(R.id.category);

                Log.d("SignupActivity", editEmail.getText().toString());
                Log.d("SignupActivity", editName.getText().toString());
                Log.d("SignupActivity", editPass.getText().toString());
                Log.d("SignupActivity", category.getSelectedItem().toString());
                String email = editEmail.getText().toString();
                String name =  editName.getText().toString();
                String pass = editPass.getText().toString();
                String categoryStr = category.getSelectedItem().toString();

                if(email!=null&&name!=null&&pass!=null&&categoryStr!=null){
                    Log.d("SignupActivity", "email is null");
                    if(email.equals("")||name.equals("")||pass.equals("")||categoryStr.equals("")){
                        alertBox("비어있는 입력이 있습니다.", "모든 입력창을 채워주세요.");
                    } else{
                        insertMember(email, pass, name, categoryStr);
                    }
                } else {
                    alertBox("비어있는 입력이 있습니다.", "모든 입력창을 채워주세요.");
                }


            }
        });

    }

    public void insertMember(String email, String pass, String name, String category){
        String url = "http://192.168.4.116:5080/funfun/insertMember.do?mem_email="+email+"&mem_pw="+pass+"&mem_favor="+category+"&mem_name="+name;
        StringRequest request = new StringRequest(
                Request.Method.POST,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("SignupActivity" , "응답:"+response);
                        alertBox("등록이 완료되었습니다.", "로그인 창으로 이동합니다.");
                        Handler delayHandler = new Handler();
                        delayHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                // TODO
                                finish();
                            }
                        }, 1000);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("SignupActivity" , "에러:"+error.getMessage());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<String,String>();

                return params;
            }


        };
        request.setShouldCache(false);
        requestQueue.add(request);
    }

    private void alertBox(String str1, String str2){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(str1).setMessage(str2);
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}
