package com.cookandroid.funfun;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

import static com.cookandroid.funfun.FundingFragment.requestQueue;


public class FindPassFragment extends Fragment {


    EditText editEmail;
    EditText pass1;
    EditText pass2;
    Button passResetBtn;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        View v = inflater.inflate(R.layout.fragment_find_pass, container, false);
        editEmail = v.findViewById(R.id.editEmail);
        pass1 = v.findViewById(R.id.pass1);
        pass2 = v.findViewById(R.id.pass2);
        passResetBtn = v.findViewById(R.id.passResetBtn);

        passResetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editEmail.getText().toString().equals("")){
                    alertBox("모든 입력을 채워주세요", "이메일을 입력해주세요");
                } else if(pass1.getText().toString().equals("")){
                    alertBox("모든 입력을 채워주세요", "재설정할 비밀번호를 입력해주세요");
                } else if(pass2.getText().toString().equals("")){
                    alertBox("모든 입력을 채워주세요", "재설정할 비밀번호를 확인해주세요");
                } else {
                    String email = editEmail.getText().toString();
                    String pass = pass1.getText().toString();
                    updatePass(email, pass);

                }
            }
        });
        return v;
    }

    private void alertBox(String str1, String str2){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(str1).setMessage(str2);
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    public void updatePass(String email, String pass){
        String url = "http://192.168.4.116:5080/funfun/changePass.do?mem_email="+email+"&mem_pw="+pass;
        StringRequest request = new StringRequest(
                Request.Method.PUT,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.d("FindPassFragment" , "응답:"+response);

                        alertBox("비밀번호 변경이 완료되었습니다.", "로그인 페이지로 이동합니다.");
                        Handler delayHandler = new Handler();
                        delayHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                // TODO
                                getActivity().finish();
                            }
                        }, 1000);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("FindPassFragment" , "에러:"+error.getMessage());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<String,String>();

                return params;
            }


        };
        request.setShouldCache(false);
        requestQueue.add(request);
    }


}
