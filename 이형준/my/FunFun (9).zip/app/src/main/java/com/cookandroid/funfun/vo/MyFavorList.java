package com.cookandroid.funfun.vo;

import java.util.ArrayList;

public class MyFavorList {

    ArrayList<MyFavor> favorList;

    public ArrayList<MyFavor> getFavorList() {
        return favorList;
    }

    public void setFavorList(ArrayList<MyFavor> favorList) {
        this.favorList = favorList;
    }
}
